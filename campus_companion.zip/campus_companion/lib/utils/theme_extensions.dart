import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF6C63FF); // accent
  static const Color background = Color(0xFFF8F9FA);
  static const Color inactive = Color(0xFF9E9E9E);
}
