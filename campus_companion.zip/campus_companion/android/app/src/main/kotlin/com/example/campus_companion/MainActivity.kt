package com.example.campus_companion

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
